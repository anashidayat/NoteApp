package com.ad_coding.noteappcourse.ui.util

object Route {
    const val noteList = "note_list"
    const val note = "note?id={id}"
}