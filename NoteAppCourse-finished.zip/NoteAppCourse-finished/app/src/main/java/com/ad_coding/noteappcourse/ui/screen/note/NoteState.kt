package com.ad_coding.noteappcourse.ui.screen.note

data class NoteState(
    val id: Int? = null,
    val title: String = "",
    val content: String = ""
)
